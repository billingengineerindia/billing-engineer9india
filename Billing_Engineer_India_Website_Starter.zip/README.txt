BILLING ENGINEER INDIA WEBSITE — START HERE
============================================

FILES
-----
index.html  = Website content and page structure
style.css   = Design, colours, layout and mobile responsiveness
script.js   = Course search, category filters and mobile navigation

HOW TO OPEN ON WINDOWS 10
-------------------------
1. Download and extract this ZIP file.
2. Open the extracted folder.
3. Double-click index.html.
4. It should open in Chrome or your default browser.

HOW TO EDIT
-----------
- To change course names, descriptions or fees: edit index.html in Notepad.
- To change colours, spacing or design: edit style.css.
- To change search/filter behaviour: edit script.js.
- Save the file, then refresh the browser.

IMPORTANT
---------
- This is a static website starter. It does not include LMS, student login, or a student dashboard.
- Course enquiry buttons open WhatsApp using the contact number configured in the HTML. Check that the number is correct before publishing.
- The Elite Batch 3.0 offer is set to ₹1,999 and regular fee ₹5,999 based on the course details provided earlier. Confirm prices before publishing.
- Other course fees are intentionally shown as "Ask for fee".
- This starter does not process online payments. If you later want online payments, add a trusted payment provider and verify payments on a secure backend.
- The website uses Google Fonts from the internet; the rest of the basic layout works locally.
- Before publishing, add your actual logo/photo if desired, verify all links, and add your final privacy/refund/terms details.
- No custom domain is included. You can publish a static site on Netlify and connect a domain separately.
