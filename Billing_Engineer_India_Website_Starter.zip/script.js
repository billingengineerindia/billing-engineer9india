const searchInput = document.getElementById('courseSearch');
const filters = [...document.querySelectorAll('.filter')];
const cards = [...document.querySelectorAll('.course-card')];
const noResults = document.getElementById('noResults');
const courseCount = document.getElementById('courseCount');
let activeFilter = 'all';

function updateCourses() {
  const query = (searchInput.value || '').trim().toLowerCase();
  let visible = 0;
  cards.forEach(card => {
    const categoryMatch = activeFilter === 'all' || card.dataset.category === activeFilter;
    const textMatch = !query || (card.dataset.search + ' ' + card.innerText).toLowerCase().includes(query);
    const show = categoryMatch && textMatch;
    card.hidden = !show;
    if (show) visible += 1;
  });
  courseCount.textContent = visible;
  noResults.hidden = visible !== 0;
}
filters.forEach(button => {
  button.addEventListener('click', () => {
    activeFilter = button.dataset.filter;
    filters.forEach(item => item.classList.toggle('active', item === button));
    updateCourses();
  });
});
searchInput.addEventListener('input', updateCourses);

const menuToggle = document.getElementById('menuToggle');
const mainNav = document.getElementById('mainNav');
menuToggle.addEventListener('click', () => {
  const open = mainNav.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', String(open));
});
mainNav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
  mainNav.classList.remove('open');
  menuToggle.setAttribute('aria-expanded', 'false');
}));
document.getElementById('year').textContent = new Date().getFullYear();
updateCourses();
